package sales.management;

public class SalesManagementApp {
	
	public static void main(String[] args) {
		Query query = new Query();
		query.initialize();
		query.displayAll();
	}

}
